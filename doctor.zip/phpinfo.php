#Use the following code to show all the information about PHP.
	<?php
	phpinfo(); // This would be used to display all of the PHP information available for the installation.
	?> 